import { Response } from 'express';
import { store } from './store';

interface ClientConnection {
  pin: string;
  res: Response;
  role: 'host' | 'participant';
  id: string;
}

const clients: Map<string, ClientConnection[]> = new Map();

export function registerSSEClient(pin: string, res: Response, role: 'host' | 'participant', clientId: string) {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.flushHeaders();

  // Send initial state immediately
  const session = store.getSession(pin);
  const participants = store.getParticipants(pin);
  const answers = store.getParticipantAnswers(pin);

  const initialPayload = {
    type: 'INIT_STATE',
    session,
    participants,
    answersCount: answers.length,
    timestamp: Date.now(),
  };

  res.write(`data: ${JSON.stringify(initialPayload)}\n\n`);

  const pinClients = clients.get(pin) || [];
  pinClients.push({ pin, res, role, id: clientId });
  clients.set(pin, pinClients);

  // Remove client on close
  res.on('close', () => {
    const list = clients.get(pin) || [];
    clients.set(
      pin,
      list.filter((c) => c.res !== res)
    );
  });
}

export function broadcastSessionEvent(pin: string, eventType: string, payloadData?: any) {
  const pinClients = clients.get(pin) || [];
  if (pinClients.length === 0) return;

  const session = store.getSession(pin);
  const participants = store.getParticipants(pin);
  const answers = store.getParticipantAnswers(pin);

  const eventPayload = {
    type: eventType,
    session,
    participants,
    answers,
    data: payloadData,
    timestamp: Date.now(),
  };

  const jsonString = JSON.stringify(eventPayload);

  pinClients.forEach((client) => {
    try {
      client.res.write(`data: ${jsonString}\n\n`);
    } catch (e) {
      console.error('SSE send error for client', client.id, e);
    }
  });
}
