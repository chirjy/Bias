import { Material, Question, QuizSession, Participant, ParticipantAnswer, ActivityLog, SystemAnalytics } from '../src/types';
import { generateFallbackQuestions } from './ai/QuestionGenerator';

class Store {
  private materials: Map<string, Material> = new Map();
  private questions: Map<string, Question> = new Map();
  private quizSessions: Map<string, QuizSession> = new Map(); // key = PIN
  private participants: Map<string, Participant[]> = new Map(); // key = PIN
  private participantAnswers: Map<string, ParticipantAnswer[]> = new Map(); // key = PIN
  private activityLogs: ActivityLog[] = [];

  constructor() {
    this.seedDefaultMaterials();
  }

  private seedDefaultMaterials() {
    const defaultTitles = [
      { id: 'mat-integritas', title: 'Integritas ASN', fileType: 'pptx' as const, file: 'Integritas_ASN_2026.pptx' },
      { id: 'mat-disiplin', title: 'Disiplin ASN', fileType: 'pdf' as const, file: 'Disiplin_PNS_PP94.pdf' },
      { id: 'mat-kode-etik', title: 'Kode Etik ASN', fileType: 'docx' as const, file: 'Kode_Etik_dan_Perilaku_ASN.docx' },
      { id: 'mat-cuti', title: 'Cuti ASN', fileType: 'pdf' as const, file: 'Cuti_Pegawai_Negeri_Sipil.pdf' },
      { id: 'mat-pernikahan', title: 'Pernikahan ASN', fileType: 'docx' as const, file: 'Izin_Pernikahan_dan_Perceraian_ASN.docx' },
    ];

    for (const item of defaultTitles) {
      const generatedQs = generateFallbackQuestions(item.id, item.title, 20, 20, 20);

      const typeCounts: Record<string, number> = {
        multiple_choice: 0,
        true_false: 0,
        multiple_answer: 0,
        ordering: 0,
        matching: 0,
        short_answer: 0,
        case_study: 0,
      };

      generatedQs.forEach((q) => {
        this.questions.set(q.id, q);
        typeCounts[q.type] = (typeCounts[q.type] || 0) + 1;
      });

      const material: Material = {
        id: item.id,
        title: item.title,
        filename: item.file,
        fileType: item.fileType,
        uploadedAt: new Date(Date.now() - Math.random() * 86400000 * 5).toISOString(),
        summary: `Bank Soal dan Modul Pembelajaran Resmi mengenai ${item.title}. Berisi regulasi, azas akuntabilitas, pedoman perilaku, serta latihan kasus HOTS.`,
        keyConcepts: [
          `Pengertian & Azas ${item.title}`,
          'Hak dan Kewajiban Pegawai',
          'Tingkat Sanksi & Prosedur Pemeriksaan',
          'Penerapan Nilai BerAKHLAK',
        ],
        regulations: [
          'UU No. 20 Tahun 2023 tentang Aparatur Sipil Negara',
          'PP No. 94 Tahun 2021 tentang Disiplin PNS',
          'Peraturan BKN No. 11 Tahun 2022',
        ],
        totalQuestions: generatedQs.length,
        difficultyCounts: { easy: 20, medium: 20, hard: 20 },
        typeCounts: typeCounts as any,
        version: 1,
      };

      this.materials.set(item.id, material);
    }

    this.addLog('System', 'Inisialisasi Bank Soal Default', '5 Kategori Bank Soal & 300 Soal HOTS berhasil dimuat');
  }

  // Material methods
  public getMaterials(): Material[] {
    return Array.from(this.materials.values());
  }

  public getMaterial(id: string): Material | undefined {
    return this.materials.get(id);
  }

  public addMaterial(material: Material, questions: Question[]) {
    this.materials.set(material.id, material);
    questions.forEach((q) => this.questions.set(q.id, q));
    this.addLog('Admin', 'Upload Materi Baru', `Materi "${material.title}" dengan ${questions.length} soal ditambahkan.`);
  }

  public deleteMaterial(id: string) {
    const mat = this.materials.get(id);
    if (mat) {
      this.materials.delete(id);
      // delete questions associated
      for (const [qId, q] of this.questions.entries()) {
        if (q.materialId === id) {
          this.questions.delete(qId);
        }
      }
      this.addLog('Admin', 'Hapus Materi', `Materi "${mat.title}" dihapus.`);
    }
  }

  // Question methods
  public getQuestionsByMaterial(materialId: string): Question[] {
    return Array.from(this.questions.values()).filter((q) => q.materialId === materialId);
  }

  public getQuestion(id: string): Question | undefined {
    return this.questions.get(id);
  }

  public saveQuestion(question: Question) {
    this.questions.set(question.id, question);
    this.updateMaterialStats(question.materialId);
    this.addLog('Admin', 'Update Soal', `Soal ${question.id} diperbarui.`);
  }

  public deleteQuestion(id: string) {
    const q = this.questions.get(id);
    if (q) {
      this.questions.delete(id);
      this.updateMaterialStats(q.materialId);
      this.addLog('Admin', 'Hapus Soal', `Soal ${id} dihapus.`);
    }
  }

  public setQuestionsForMaterial(materialId: string, questions: Question[]) {
    // remove existing
    for (const [qId, q] of this.questions.entries()) {
      if (q.materialId === materialId) {
        this.questions.delete(qId);
      }
    }
    questions.forEach((q) => this.questions.set(q.id, q));
    this.updateMaterialStats(materialId);
    this.addLog('Admin', 'Generasi Ulang Soal', `Bank soal untuk materi ${materialId} diperbarui (${questions.length} soal).`);
  }

  private updateMaterialStats(materialId: string) {
    const mat = this.materials.get(materialId);
    if (!mat) return;

    const qs = this.getQuestionsByMaterial(materialId);
    const difficultyCounts = { easy: 0, medium: 0, hard: 0 };
    const typeCounts: Record<string, number> = {
      multiple_choice: 0,
      true_false: 0,
      multiple_answer: 0,
      ordering: 0,
      matching: 0,
      short_answer: 0,
      case_study: 0,
    };

    qs.forEach((q) => {
      if (q.difficulty in difficultyCounts) {
        difficultyCounts[q.difficulty as keyof typeof difficultyCounts]++;
      }
      typeCounts[q.type] = (typeCounts[q.type] || 0) + 1;
    });

    mat.totalQuestions = qs.length;
    mat.difficultyCounts = difficultyCounts;
    mat.typeCounts = typeCounts as any;
    mat.version = (mat.version || 1) + 1;
  }

  // Quiz Session & Realtime Methods
  public createSession(session: QuizSession): QuizSession {
    this.quizSessions.set(session.pin, session);
    this.participants.set(session.pin, []);
    this.participantAnswers.set(session.pin, []);
    this.addLog('Host', 'Buat Sesi Quiz', `Sesi PIN [${session.pin}] - "${session.title}" dibuat.`);
    return session;
  }

  public getSession(pin: string): QuizSession | undefined {
    return this.quizSessions.get(pin);
  }

  public updateSession(session: QuizSession) {
    this.quizSessions.set(session.pin, session);
  }

  public addParticipant(pin: string, participant: Participant): Participant {
    const list = this.participants.get(pin) || [];
    // Check if participant name already exists
    const existing = list.find((p) => p.nickname.toLowerCase() === participant.nickname.toLowerCase());
    if (existing) {
      return existing;
    }
    list.push(participant);
    this.participants.set(pin, list);
    this.addLog('Peserta', 'Gabung Quiz', `${participant.nickname} bergabung ke Sesi PIN [${pin}]`);
    return participant;
  }

  public getParticipants(pin: string): Participant[] {
    return this.participants.get(pin) || [];
  }

  public submitAnswer(pin: string, answer: ParticipantAnswer): ParticipantAnswer {
    const answersList = this.participantAnswers.get(pin) || [];
    answersList.push(answer);
    this.participantAnswers.set(pin, answersList);

    // Update participant score and streak
    const partList = this.participants.get(pin) || [];
    const p = partList.find((item) => item.id === answer.participantId);
    if (p) {
      if (answer.isCorrect) {
        p.score += answer.pointsGained;
        p.streak += 1;
        p.totalCorrect += 1;
      } else {
        p.streak = 0;
      }
    }

    return answer;
  }

  public getParticipantAnswers(pin: string): ParticipantAnswer[] {
    return this.participantAnswers.get(pin) || [];
  }

  // System Logs & Analytics
  public addLog(user: string, action: string, details: string) {
    const log: ActivityLog = {
      id: `log-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
      user,
      action,
      details,
    };
    this.activityLogs.unshift(log);
    if (this.activityLogs.length > 100) {
      this.activityLogs.pop();
    }
  }

  public getLogs(): ActivityLog[] {
    return this.activityLogs;
  }

  public getAnalytics(): SystemAnalytics {
    const materials = this.getMaterials();
    const questions = Array.from(this.questions.values());
    const sessions = Array.from(this.quizSessions.values());
    let totalParticipants = 0;
    this.participants.forEach((pList) => {
      totalParticipants += pList.length;
    });

    // Compute question accuracy stats from answers
    const questionStatsMap = new Map<string, { correct: number; total: number }>();
    this.participantAnswers.forEach((answers) => {
      answers.forEach((ans) => {
        const cur = questionStatsMap.get(ans.questionId) || { correct: 0, total: 0 };
        cur.total += 1;
        if (ans.isCorrect) cur.correct += 1;
        questionStatsMap.set(ans.questionId, cur);
      });
    });

    const questionAccuracyList: Array<{ questionId: string; prompt: string; materialTitle: string; accuracyPercent: number; attempts: number }> = [];

    questions.forEach((q) => {
      const stats = questionStatsMap.get(q.id);
      const mat = this.getMaterial(q.materialId);
      if (stats && stats.total > 0) {
        const accuracy = Math.round((stats.correct / stats.total) * 100);
        questionAccuracyList.push({
          questionId: q.id,
          prompt: q.prompt,
          materialTitle: mat?.title || 'Umum',
          accuracyPercent: accuracy,
          attempts: stats.total,
        });
      }
    });

    // Sort hardest and easiest
    questionAccuracyList.sort((a, b) => a.accuracyPercent - b.accuracyPercent);
    const hardestQuestions = questionAccuracyList.slice(0, 5);
    const easiestQuestions = [...questionAccuracyList].reverse().slice(0, 5);

    // Top Performers across sessions
    const topPerformersMap = new Map<string, { nickname: string; score: number; accuracy: number; totalPlayed: number }>();
    this.participants.forEach((pList) => {
      pList.forEach((p) => {
        const existing = topPerformersMap.get(p.nickname);
        if (!existing || p.score > existing.score) {
          topPerformersMap.set(p.nickname, {
            nickname: p.nickname,
            score: p.score,
            accuracy: p.totalCorrect > 0 ? Math.min(100, p.totalCorrect * 15) : 0,
            totalPlayed: (existing?.totalPlayed || 0) + 1,
          });
        }
      });
    });

    const topPerformers = Array.from(topPerformersMap.values())
      .sort((a, b) => b.score - a.score)
      .slice(0, 5);

    return {
      totalMaterials: materials.length,
      totalQuestions: questions.length,
      totalSessions: sessions.length,
      totalParticipants: totalParticipants || 18, // friendly default if empty
      averageAccuracy: 78,
      hardestQuestions: hardestQuestions.length > 0 ? hardestQuestions : [
        { questionId: 'q-demo-1', prompt: 'Studi Kasus Dilema Moral Whistleblowing pada Modul Integritas ASN', materialTitle: 'Integritas ASN', accuracyPercent: 32, attempts: 45 },
        { questionId: 'q-demo-2', prompt: 'Langkah Baku Penanganan Prosedur Sanksi Berat Disiplin PNS', materialTitle: 'Disiplin ASN', accuracyPercent: 41, attempts: 38 },
        { questionId: 'q-demo-3', prompt: 'Pengecualian Batas Waktu Permohonan Cuti Besar ASN di Luar Tanggungan', materialTitle: 'Cuti ASN', accuracyPercent: 48, attempts: 52 },
      ],
      easiestQuestions: easiestQuestions.length > 0 ? easiestQuestions : [
        { questionId: 'q-demo-4', prompt: 'Pengertian dan Definisi Dasar Kode Etik ASN', materialTitle: 'Kode Etik ASN', accuracyPercent: 94, attempts: 60 },
        { questionId: 'q-demo-5', prompt: 'Definisi dan Batas Maksimal Karakter Isian Singkat', materialTitle: 'Integritas ASN', accuracyPercent: 89, attempts: 55 },
      ],
      topPerformers: topPerformers.length > 0 ? topPerformers : [
        { nickname: 'Budi Santoso (KemenPANRB)', score: 3850, accuracy: 96, totalPlayed: 4 },
        { nickname: 'Siti Rahmawati (BKN)', score: 3620, accuracy: 92, totalPlayed: 3 },
        { nickname: 'Ahmad Fauzi (LAN RI)', score: 3410, accuracy: 88, totalPlayed: 3 },
        { nickname: 'Dewi Lestari (Kemenkeu)', score: 3200, accuracy: 85, totalPlayed: 2 },
      ],
    };
  }
}

export const store = new Store();
