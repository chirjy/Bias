import React, { useState, useEffect } from 'react';
import { QuizSession, Question, Participant, ParticipantAnswer } from '../types';
import { Users, Clock, CheckCircle2, XCircle, Trophy, Flame, Sparkles, Send, ArrowRight, Lock } from 'lucide-react';
import confetti from 'canvas-confetti';

interface ParticipantViewProps {
  initialPin?: string;
  onExit?: () => void;
  onRequestHostAccess?: () => void;
}

export const ParticipantView: React.FC<ParticipantViewProps> = ({
  initialPin = '',
  onExit,
  onRequestHostAccess,
}) => {
  const [pin, setPin] = useState<string>(initialPin);
  const [nickname, setNickname] = useState<string>('');
  const [selectedAvatar, setSelectedAvatar] = useState<string>('😊');
  const [joinedParticipant, setJoinedParticipant] = useState<Participant | null>(null);
  const [session, setSession] = useState<QuizSession | null>(null);
  const [currentQuestion, setCurrentQuestion] = useState<Question | null>(null);
  const [selectedAnswerData, setSelectedAnswerData] = useState<any>(null);
  const [hasSubmitted, setHasSubmitted] = useState<boolean>(false);
  const [lastAnswerResult, setLastAnswerResult] = useState<{ isCorrect: boolean; pointsGained: number } | null>(null);
  const [timeLeft, setTimeLeft] = useState<number>(30);
  const [startTimeMs, setStartTimeMs] = useState<number>(0);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const avatars = ['😊', '🚀', '💡', '🎓', '👑', '🔥', '🌟', '🎯', '🦁', '🦊'];

  // Listen to SSE updates
  useEffect(() => {
    if (!joinedParticipant || !pin) return;

    const eventSource = new EventSource(`/api/quiz/live-stream/${pin}?role=participant`);

    eventSource.onmessage = (event) => {
      try {
        const payload = JSON.parse(event.data);
        if (payload.session) {
          setSession(payload.session);
        }

        if (payload.type === 'QUESTION_CHANGED' || payload.type === 'INIT_STATE') {
          fetchCurrentQuestion(pin);
          setHasSubmitted(false);
          setSelectedAnswerData(null);
          setLastAnswerResult(null);
          setStartTimeMs(Date.now());
        }

        if (payload.type === 'QUIZ_FINISHED') {
          confetti({ particleCount: 150, spread: 80, origin: { y: 0.6 } });
        }
      } catch (e) {
        console.error('SSE Error', e);
      }
    };

    return () => {
      eventSource.close();
    };
  }, [joinedParticipant, pin]);

  // Countdown timer for current question
  useEffect(() => {
    if (!session || session.status !== 'active') return;

    const interval = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [session?.status, session?.currentQuestionIndex]);

  const fetchCurrentQuestion = async (sessionPin: string) => {
    try {
      const res = await fetch(`/api/quiz/session/${sessionPin}`);
      const data = await res.json();
      if (data.session) setSession(data.session);
      if (data.currentQuestion) {
        setCurrentQuestion(data.currentQuestion);
        setTimeLeft(data.session.timerSeconds || 30);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleJoin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!pin || !nickname) return;
    setErrorMessage(null);

    try {
      const res = await fetch(`/api/quiz/session/${pin}/join`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          nickname,
          avatar: selectedAvatar,
        }),
      });

      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || 'PIN Quiz tidak ditemukan');
      }

      const data = await res.json();
      setJoinedParticipant(data.participant);
      setSession(data.session);
      fetchCurrentQuestion(pin);
      setStartTimeMs(Date.now());
    } catch (err: any) {
      setErrorMessage(err.message || 'Gagal bergabung ke kuis');
    }
  };

  const handleSubmitAnswer = async (answerPayloadData: any) => {
    if (hasSubmitted || !currentQuestion || !joinedParticipant) return;

    setSelectedAnswerData(answerPayloadData);
    setHasSubmitted(true);
    const timeTakenMs = Date.now() - startTimeMs;

    try {
      const res = await fetch(`/api/quiz/session/${pin}/submit-answer`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          participantId: joinedParticipant.id,
          questionId: currentQuestion.id,
          answerData: answerPayloadData,
          timeTakenMs,
        }),
      });

      const data = await res.json();
      setLastAnswerResult({
        isCorrect: data.isCorrect,
        pointsGained: data.pointsGained,
      });

      if (data.isCorrect) {
        confetti({ particleCount: 50, spread: 60, origin: { y: 0.7 } });
        setJoinedParticipant((prev) =>
          prev
            ? {
                ...prev,
                score: prev.score + data.pointsGained,
                streak: prev.streak + 1,
              }
            : null
        );
      } else {
        setJoinedParticipant((prev) => (prev ? { ...prev, streak: 0 } : null));
      }
    } catch (err) {
      console.error(err);
    }
  };

  /* Step 1: Join Screen */
  if (!joinedParticipant) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center p-4">
        <div className="max-w-md w-full bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl text-white">
          <div className="text-center mb-6">
            <div className="w-12 h-12 mx-auto rounded-2xl bg-gradient-to-br from-emerald-500 to-indigo-600 text-white flex items-center justify-center font-black text-2xl mb-3 shadow-lg shadow-emerald-500/20">
              B
            </div>
            <h2 className="text-2xl font-black text-white">BIAS</h2>
            <p className="text-xs font-medium text-emerald-400 mt-0.5">Belajar Integritas Asyik dan Seru</p>
            <p className="text-[11px] text-slate-400 italic mt-1 bg-slate-800/50 py-1.5 px-3 rounded-xl border border-slate-800 inline-block">
              "Hilangkan Bias, Bangun Integritas."
            </p>
          </div>

          <form onSubmit={handleJoin} className="space-y-4 text-xs">
            {errorMessage && (
              <div className="p-3 bg-rose-500/10 border border-rose-500/30 text-rose-300 rounded-xl text-center">
                {errorMessage}
              </div>
            )}

            <div>
              <label className="block text-slate-400 mb-1 font-semibold">PIN Quiz (6 Digit):</label>
              <input
                type="text"
                value={pin}
                onChange={(e) => setPin(e.target.value)}
                maxLength={6}
                placeholder="Contoh: 384621"
                className="w-full bg-slate-800 border border-slate-700 rounded-2xl p-3.5 text-center font-mono font-black text-xl text-emerald-400 tracking-widest outline-none focus:border-emerald-500"
              />
            </div>

            <div>
              <label className="block text-slate-400 mb-1 font-semibold">Nama Panggilan Anda:</label>
              <input
                type="text"
                value={nickname}
                onChange={(e) => setNickname(e.target.value)}
                placeholder="Masukkan nama Anda..."
                className="w-full bg-slate-800 border border-slate-700 rounded-2xl p-3 text-sm text-white outline-none focus:border-indigo-500"
              />
            </div>

            <div>
              <label className="block text-slate-400 mb-1 font-semibold">Pilih Avatar Icon:</label>
              <div className="flex flex-wrap items-center justify-center gap-2 p-2 bg-slate-800/60 rounded-2xl border border-slate-800">
                {avatars.map((av) => (
                  <button
                    key={av}
                    type="button"
                    onClick={() => setSelectedAvatar(av)}
                    className={`w-9 h-9 text-lg rounded-xl flex items-center justify-center transition-all ${
                      selectedAvatar === av ? 'bg-indigo-600 scale-110 shadow-md' : 'hover:bg-slate-700'
                    }`}
                  >
                    {av}
                  </button>
                ))}
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-3.5 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-sm rounded-2xl shadow-lg shadow-emerald-500/20 transition-all flex items-center justify-center gap-2 mt-2"
            >
              Gabung Sesi Permainan <ArrowRight className="w-4 h-4" />
            </button>
          </form>

          {/* Host / Admin Access link */}
          {onRequestHostAccess && (
            <div className="mt-6 pt-4 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
              <span>Pengajar / Host Quiz?</span>
              <button
                type="button"
                onClick={onRequestHostAccess}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 hover:text-white text-slate-300 font-medium rounded-xl border border-slate-700/60 transition-all"
              >
                <Lock className="w-3.5 h-3.5 text-indigo-400" /> Akses Admin / Host
              </button>
            </div>
          )}
        </div>
      </div>
    );
  }

  /* Step 2: Lobby Wait Screen */
  if (session?.status === 'lobby' || session?.currentQuestionIndex === -1) {
    return (
      <div className="min-h-screen bg-slate-950 text-white p-4 flex flex-col items-center justify-center text-center">
        <div className="max-w-md w-full bg-slate-900 border border-slate-800 rounded-3xl p-8 shadow-2xl space-y-6">
          <div className="text-4xl animate-bounce">{joinedParticipant.avatar}</div>
          <h2 className="text-2xl font-black">Anda Berhasil Terhubung!</h2>
          <p className="text-xs text-slate-400">
            Halo <strong className="text-emerald-400">{joinedParticipant.nickname}</strong>, mohon menunggu host memulai soal pertama...
          </p>

          <div className="p-4 bg-slate-800/60 rounded-2xl border border-slate-800 flex items-center justify-between text-xs">
            <span className="text-slate-400">PIN Sesi:</span>
            <span className="font-mono font-bold text-indigo-400">{session.pin}</span>
          </div>

          <div className="p-3 bg-indigo-500/10 border border-indigo-500/30 rounded-2xl text-xs text-indigo-300 animate-pulse">
            Ready to play! Perhatikan layar host.
          </div>
        </div>
      </div>
    );
  }

  /* Step 3: Finished / Podium Screen */
  if (session?.status === 'finished') {
    return (
      <div className="min-h-screen bg-slate-950 text-white p-4 flex flex-col items-center justify-center text-center">
        <div className="max-w-md w-full bg-slate-900 border border-slate-800 rounded-3xl p-8 shadow-2xl space-y-6">
          <div className="text-5xl">{joinedParticipant.avatar}</div>
          <h2 className="text-2xl font-black text-amber-400">Permainan Selesai!</h2>
          <p className="text-xs text-slate-300">Terima kasih telah berpartisipasi dalam quiz interaktif ini.</p>

          <div className="p-6 bg-slate-800/80 border border-slate-700 rounded-2xl space-y-2">
            <p className="text-xs text-slate-400">Total Skor Akhir Anda:</p>
            <p className="text-3xl font-black text-emerald-400 font-mono">{joinedParticipant.score} Points</p>
          </div>

          {onExit && (
            <button
              onClick={onExit}
              className="w-full py-3 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold rounded-2xl text-xs"
            >
              Kembali ke Menu Utama
            </button>
          )}
        </div>
      </div>
    );
  }

  /* Step 4: Active Question View */
  return (
    <div className="min-h-screen bg-slate-950 text-white p-4 sm:p-6 flex flex-col justify-between max-w-lg mx-auto">
      {/* Top Participant Status Bar */}
      <div className="flex items-center justify-between bg-slate-900 border border-slate-800 p-3.5 rounded-2xl shadow-lg mb-4">
        <div className="flex items-center gap-2">
          <span className="text-xl">{joinedParticipant.avatar}</span>
          <div>
            <p className="font-bold text-xs text-white line-clamp-1">{joinedParticipant.nickname}</p>
            <p className="text-[10px] text-emerald-400 font-mono font-bold">{joinedParticipant.score} pts</p>
          </div>
        </div>

        {joinedParticipant.streak > 1 && (
          <div className="px-2.5 py-1 bg-amber-500/20 border border-amber-500/30 text-amber-300 rounded-full text-[10px] font-bold flex items-center gap-1">
            <Flame className="w-3.5 h-3.5 text-amber-400 fill-current animate-pulse" />
            <span>{joinedParticipant.streak} Streak!</span>
          </div>
        )}

        <div className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-500/10 border border-amber-500/30 text-amber-400 rounded-xl font-mono text-xs font-bold">
          <Clock className="w-3.5 h-3.5 animate-spin" />
          <span>{timeLeft}s</span>
        </div>
      </div>

      {/* Main Question Card */}
      {currentQuestion && (
        <div className="space-y-4 my-auto">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-2xl">
            <div className="flex items-center justify-between text-[10px] font-bold text-slate-400 mb-2">
              <span>
                Soal #{session.currentQuestionIndex + 1} / {session.questionIds.length}
              </span>
              <span className="uppercase text-indigo-400">{currentQuestion.type}</span>
            </div>

            {currentQuestion.caseStudyScenario && (
              <div className="mb-3 p-3 bg-slate-800/80 border-l-2 border-indigo-500 rounded-r-xl text-xs text-slate-300 italic">
                {currentQuestion.caseStudyScenario}
              </div>
            )}

            <h3 className="text-base sm:text-lg font-bold text-white leading-snug">{currentQuestion.prompt}</h3>
          </div>

          {/* Touch Options / Input Area */}
          {!hasSubmitted ? (
            <div className="space-y-2.5">
              {currentQuestion.options && currentQuestion.options.length > 0 && (
                <div className="grid grid-cols-1 gap-2.5">
                  {currentQuestion.options.map((opt, idx) => {
                    const buttonColors = [
                      'bg-indigo-600/20 hover:bg-indigo-600/30 border-indigo-500/40 text-indigo-200',
                      'bg-purple-600/20 hover:bg-purple-600/30 border-purple-500/40 text-purple-200',
                      'bg-emerald-600/20 hover:bg-emerald-600/30 border-emerald-500/40 text-emerald-200',
                      'bg-amber-600/20 hover:bg-amber-600/30 border-amber-500/40 text-amber-200',
                    ];
                    const colorClass = buttonColors[idx % buttonColors.length];

                    return (
                      <button
                        key={opt.id}
                        onClick={() => handleSubmitAnswer(opt.id)}
                        className={`w-full p-4 rounded-2xl border text-left text-sm font-semibold transition-all active:scale-95 shadow-md ${colorClass}`}
                      >
                        {opt.text}
                      </button>
                    );
                  })}
                </div>
              )}

              {currentQuestion.type === 'short_answer' && (
                <div className="space-y-2">
                  <input
                    type="text"
                    maxLength={30}
                    placeholder="Tulis jawaban singkat (max 30 karakter)..."
                    className="w-full bg-slate-900 border border-slate-700 rounded-2xl p-4 text-sm text-white outline-none focus:border-indigo-500"
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        handleSubmitAnswer((e.target as HTMLInputElement).value);
                      }
                    }}
                  />
                  <p className="text-[10px] text-slate-500 text-center">Tekan Enter untuk mengirim jawaban</p>
                </div>
              )}
            </div>
          ) : (
            /* Answer Locked / Result Screen */
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 text-center space-y-4 animate-fade-in shadow-2xl">
              {lastAnswerResult?.isCorrect ? (
                <div className="space-y-2">
                  <div className="w-16 h-16 mx-auto rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-3xl">
                    <CheckCircle2 className="w-10 h-10 text-emerald-400" />
                  </div>
                  <h4 className="text-xl font-black text-emerald-400">Jawaban Benar!</h4>
                  <p className="text-sm font-mono font-bold text-amber-300">
                    +{lastAnswerResult.pointsGained} Points diperoleh
                  </p>
                </div>
              ) : (
                <div className="space-y-2">
                  <div className="w-16 h-16 mx-auto rounded-full bg-rose-500/20 text-rose-400 flex items-center justify-center font-bold text-3xl">
                    <XCircle className="w-10 h-10 text-rose-400" />
                  </div>
                  <h4 className="text-xl font-black text-rose-400">Jawaban Belum Tepat</h4>
                  <p className="text-xs text-slate-400">Tetap semangat untuk soal berikutnya!</p>
                </div>
              )}

              <p className="text-xs text-slate-500 italic pt-2">
                Menunggu host melanjutkan ke soal berikutnya...
              </p>
            </div>
          )}
        </div>
      )}

      {/* Footer info */}
      <div className="mt-4 text-center text-[10px] text-slate-500">
        Mentiquiz AI • Mobile First Interactive Engine
      </div>
    </div>
  );
};
