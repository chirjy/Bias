import React, { useState } from 'react';
import { UploadCloud, Sparkles, FileText, CheckCircle2, AlertCircle, Loader2, ArrowRight } from 'lucide-react';
import { Material } from '../types';

interface MaterialUploaderProps {
  onUploadSuccess: (material: Material) => void;
  onCancel?: () => void;
}

export const MaterialUploader: React.FC<MaterialUploaderProps> = ({ onUploadSuccess }) => {
  const [file, setFile] = useState<File | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [currentStep, setCurrentStep] = useState<number>(0);
  const [error, setError] = useState<string | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
      setError(null);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      setFile(e.dataTransfer.files[0]);
      setError(null);
    }
  };

  const processUpload = async () => {
    if (!file) return;

    setIsUploading(true);
    setError(null);
    setCurrentStep(1); // Reading document

    try {
      const reader = new FileReader();

      reader.onload = async () => {
        const result = reader.result as string;
        const base64Content = result.split(',')[1] || result;

        setCurrentStep(2); // AI Analyzing & Summarizing

        setTimeout(() => {
          setCurrentStep(3); // Generating 60 questions
        }, 1500);

        const res = await fetch('/api/materials/upload', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            fileName: file.name,
            fileType: file.name.split('.').pop()?.toLowerCase() || 'pptx',
            fileBase64: base64Content,
          }),
        });

        if (!res.ok) {
          const errData = await res.json();
          throw new Error(errData.error || 'Gagal mengunggah dan memproses materi');
        }

        const data = await res.json();
        setCurrentStep(4); // Finished

        setTimeout(() => {
          setIsUploading(false);
          onUploadSuccess(data.material);
        }, 800);
      };

      reader.onerror = () => {
        throw new Error('Gagal membaca berkas lokal');
      };

      reader.readAsDataURL(file);
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Terjadi kesalahan sistem');
      setIsUploading(false);
      setCurrentStep(0);
    }
  };

  return (
    <div className="max-w-4xl mx-auto p-6">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-8 shadow-xl text-slate-100">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-3 rounded-xl bg-indigo-500/20 text-indigo-400 border border-indigo-500/30">
            <Sparkles className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-white">Upload Materi Pembelajaran & PPT</h2>
            <p className="text-sm text-slate-400">
              AI akan membaca materi, membuat ringkasan, dan menghasilkan 60 Soal Otomatis (20 Mudah, 20 Sedang, 20 Sulit)
            </p>
          </div>
        </div>

        {/* Drag & Drop Box */}
        {!isUploading && (
          <div
            onDragOver={(e) => e.preventDefault()}
            onDrop={handleDrop}
            className="border-2 border-dashed border-slate-700 hover:border-indigo-500 bg-slate-800/40 rounded-2xl p-10 text-center transition-colors cursor-pointer group"
          >
            <input
              type="file"
              id="fileInput"
              onChange={handleFileChange}
              accept=".ppt,.pptx,.pdf,.docx,.txt,.md"
              className="hidden"
            />
            <label htmlFor="fileInput" className="cursor-pointer block">
              <UploadCloud className="w-14 h-14 mx-auto text-indigo-400 group-hover:scale-110 transition-transform mb-4" />
              <p className="text-base font-semibold text-white mb-1">
                {file ? file.name : 'Klik untuk memilih file atau seret file ke sini'}
              </p>
              <p className="text-xs text-slate-400 max-w-md mx-auto mb-4">
                Mendukung format PPT, PPTX, PDF, DOCX, TXT. AI akan membuat Bank Soal otomatis khusus materi tersebut.
              </p>
              <div className="inline-flex items-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-medium rounded-xl text-xs transition-all shadow-md shadow-indigo-600/30">
                Pilih Berkas Materi <ArrowRight className="w-4 h-4" />
              </div>
            </label>
          </div>
        )}

        {/* Error message */}
        {error && (
          <div className="mt-4 p-4 bg-rose-500/10 border border-rose-500/30 text-rose-300 rounded-xl flex items-center gap-3 text-sm">
            <AlertCircle className="w-5 h-5 flex-shrink-0 text-rose-400" />
            <span>{error}</span>
          </div>
        )}

        {/* Selected file preview before start */}
        {file && !isUploading && (
          <div className="mt-6 flex items-center justify-between p-4 bg-slate-800/80 rounded-xl border border-slate-700">
            <div className="flex items-center gap-3">
              <FileText className="w-6 h-6 text-indigo-400" />
              <div>
                <p className="text-sm font-semibold text-white">{file.name}</p>
                <p className="text-xs text-slate-400">{(file.size / (1024 * 1024)).toFixed(2)} MB</p>
              </div>
            </div>
            <button
              onClick={processUpload}
              className="px-5 py-2.5 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white font-semibold rounded-xl text-sm shadow-lg shadow-indigo-500/25 transition-all flex items-center gap-2"
            >
              <Sparkles className="w-4 h-4" /> Mulai AI Generator Soal
            </button>
          </div>
        )}

        {/* Progress steps when uploading */}
        {isUploading && (
          <div className="mt-8 space-y-6">
            <div className="text-center">
              <Loader2 className="w-10 h-10 animate-spin mx-auto text-indigo-400 mb-2" />
              <h3 className="text-base font-bold text-white">Gemini AI Sedang Memproses Berkas Anda...</h3>
              <p className="text-xs text-slate-400">Mohon tunggu sebentar, AI sedang membaca dan menghasilkan 60 soal HOTS.</p>
            </div>

            <div className="space-y-3 bg-slate-800/60 p-6 rounded-2xl border border-slate-700/80">
              <StepItem
                stepNumber={1}
                title="Ekstraksi Teks Materi & Slide"
                description="Membaca dan memisahkan konten bab, poin utama, dan definisi"
                currentStep={currentStep}
              />
              <StepItem
                stepNumber={2}
                title="AI Analisis Konsep & Regulasi (Gemini 3.6 Flash)"
                description="Mengidentifikasi pasal perundang-undangan dan angka penting"
                currentStep={currentStep}
              />
              <StepItem
                stepNumber={3}
                title="Generasi Bank Soal HOTS (60 Soal Otomatis)"
                description="Membuat 20 Mudah, 20 Sedang, 20 Sulit untuk 7 Tipe Soal"
                currentStep={currentStep}
              />
              <StepItem
                stepNumber={4}
                title="Penyimpanan & Validasi Kualitas Soal"
                description="Soal berhasil disimpan dan siap digunakan dalam Live Quiz"
                currentStep={currentStep}
              />
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

interface StepItemProps {
  stepNumber: number;
  title: string;
  description: string;
  currentStep: number;
}

const StepItem: React.FC<StepItemProps> = ({ stepNumber, title, description, currentStep }) => {
  const isDone = currentStep > stepNumber;
  const isCurrent = currentStep === stepNumber;

  return (
    <div className={`flex items-start gap-3 p-3 rounded-xl transition-colors ${isCurrent ? 'bg-indigo-500/10 border border-indigo-500/30' : ''}`}>
      <div className="mt-0.5">
        {isDone ? (
          <CheckCircle2 className="w-5 h-5 text-emerald-400" />
        ) : isCurrent ? (
          <Loader2 className="w-5 h-5 text-indigo-400 animate-spin" />
        ) : (
          <div className="w-5 h-5 rounded-full border border-slate-600 text-[10px] text-slate-500 flex items-center justify-center font-bold">
            {stepNumber}
          </div>
        )}
      </div>
      <div>
        <p className={`text-sm font-semibold ${isDone ? 'text-emerald-300' : isCurrent ? 'text-indigo-300' : 'text-slate-400'}`}>
          {title}
        </p>
        <p className="text-xs text-slate-500">{description}</p>
      </div>
    </div>
  );
};
